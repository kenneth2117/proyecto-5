package com.example.proyecto4.VistaFragment;

import com.example.proyecto4.Adaptador.adaptador;
import com.example.proyecto4.mascota;

import java.util.ArrayList;

public interface iRecyclerViewFragments {
    public void generarLinearLayoutGrid();
    public adaptador crearAdaptador(ArrayList<mascota> lista_mascotas);
    public void inicializarAdaptadorRV(adaptador adp);
}
