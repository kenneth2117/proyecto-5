package com.example.proyecto4.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.proyecto4.mascota;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private Context context;
    public BaseDatos(@Nullable Context context) {
        super(context, ConstantesBaseDatos.DataBase_Name, null, ConstantesBaseDatos.DataBase_Version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
     String query = "CREATE TABLE "+ConstantesBaseDatos.TABLE_Mascotas+"("+ConstantesBaseDatos.TABLE_Mascotas_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
             ConstantesBaseDatos.TABLE_Mascotas_NOMBRE+" TEXT, "+
             ConstantesBaseDatos.TABLE_Mascotas_FOTO+" INTEGER, "+
             ConstantesBaseDatos.TABLE_Mascotas_LIKES+" INTEGER "
             +")";
     String queryCreartablalikes = "CREATE TABLE "+ConstantesBaseDatos.TABLE_LIKES_MASCOTAS+"(" +
             ConstantesBaseDatos.TABLE_LIKES_MASCOTAS_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
             ConstantesBaseDatos.TABLE_LIKES_MASCOTAS_ID_MASCOTA+" INTEGER, "+
             ConstantesBaseDatos.TABLE_LIKES_MASCOTAS_NUMERO_LIKES+" INTEGER, "+
             "FOREIGN KEY("+ConstantesBaseDatos.TABLE_LIKES_MASCOTAS_ID_MASCOTA+") "+
             "REFERENCES "+ConstantesBaseDatos.TABLE_Mascotas+"(" +ConstantesBaseDatos.TABLE_Mascotas_ID+ ")"+
             ")";
        sqLiteDatabase.execSQL(query);
        sqLiteDatabase.execSQL(queryCreartablalikes);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ConstantesBaseDatos.TABLE_Mascotas);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ConstantesBaseDatos.TABLE_LIKES_MASCOTAS);
        onCreate(sqLiteDatabase);
    }

    public ArrayList<mascota> Obtener_Todos_Mascotas(){
        ArrayList<mascota> lista = new ArrayList<>();
        String query ="SELECT * FROM "+ConstantesBaseDatos.TABLE_Mascotas;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor Registros = db.rawQuery(query,null);

        while(Registros.moveToNext()){
            mascota mascota_actual = new mascota();
            mascota_actual.setId(Registros.getInt(0));
            mascota_actual.setNombre(Registros.getString(1));
            mascota_actual.setFoto(Registros.getInt(2));
          //  mascota_actual.setCantidad_likes(Registros.getInt(3));
            lista.add(mascota_actual);
        }
        db.close();
        return lista;
    }

    public void insertar_Mascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_Mascotas,null,contentValues);
        db.close();
    }
}
