package com.example.proyecto4.Adaptador;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyecto4.R;
import com.example.proyecto4.mascota;

import java.util.ArrayList;

public class adaptador extends RecyclerView.Adapter<adaptador.ViewHolder> {
    ArrayList<mascota> listaMascota;

    public adaptador(ArrayList<mascota> listaMascota) {
        this.listaMascota = listaMascota;
    }

    @NonNull
    @Override
    public adaptador.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista,null,false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final adaptador.ViewHolder holder, int position) {
        final  mascota m = listaMascota.get(position);
        holder.foto.setImageResource(m.getFoto());
        holder.nombre.setText(m.getNombre());
        String cantidad = String.valueOf(m.getCantidad_likes());
        holder.cant_likes.setText(cantidad);

        holder.ib_LIke.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //aumenta la cantidad de likes en los datos y luego en se modifca el dato que se muestra en el textview
                String cantidad = String.valueOf(m.getCantidad_likes()+1);
                holder.cant_likes.setText(cantidad);
                m.setCantidad_likes(Integer.parseInt(cantidad));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaMascota.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView foto;
        TextView nombre;
        TextView cant_likes;
        ImageButton ib_LIke;
        ImageView foto_estrella;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            foto =  itemView.findViewById(R.id.img_foto);
            nombre =  itemView.findViewById(R.id.tvNombre);
            cant_likes =  itemView.findViewById(R.id.tvTotalLkes);
            ib_LIke =  itemView.findViewById(R.id.ib_like);
            foto_estrella = itemView.findViewById(R.id.img_star);
        }
    }
}
