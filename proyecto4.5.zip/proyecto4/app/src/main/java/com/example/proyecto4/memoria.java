package com.example.proyecto4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileOutputStream;

public class memoria extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memoria);
    }

    public void guardarArchivo(View view) {
        try {
            EditText edt_nom = (EditText) findViewById(R.id.edt_nom);
            String nombre = edt_nom.getText().toString();
            FileOutputStream outputStream = null;
            outputStream = openFileOutput("Mi archivo.txt", Context.MODE_PRIVATE);
            outputStream.write(nombre.getBytes());
            outputStream.close();
            Toast.makeText(this, "El archivo se a creado", Toast.LENGTH_SHORT).show();
            edt_nom.setText("");
            
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "Hubo un error con la escritura del archivo", Toast.LENGTH_LONG).show();
        }
    }

    public void guardar_preferencia(View view) {
        SharedPreferences mipreferencia = getSharedPreferences("MisDatosPersonales",Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = mipreferencia.edit();

        EditText edt_nom = (EditText) findViewById(R.id.edt_nom);
        EditText edt_Correo =(EditText) findViewById(R.id.edt_correo);

        String nombre = edt_nom.getText().toString();
        String correo = edt_Correo.getText().toString();

        editor.putString("nom",nombre);
        editor.putString("email",correo);;

        editor.commit();
        Toast.makeText(this, "Se ha creado la preferencia  compartida", Toast.LENGTH_SHORT).show();
        edt_nom.setText("");
        edt_Correo.setText("");

    }

    public void mostrar_preferencia(View view){
//busca ell nombre del archivo para leer
    SharedPreferences miPreferenciaCompartida = getSharedPreferences("MisDatosPersonales",Context.MODE_PRIVATE);
    // se le pasa el nombre de la variable para leer el contenido en caso de que no la encuentre muestra ese mensaje.
    String nombre = miPreferenciaCompartida.getString("nom","No existe esa variable");
    String correo = miPreferenciaCompartida.getString("email","No existe esa variable");

    String preferencia = "\nNombre: "+nombre+"\nCorreo: "+correo;
        TextView tv_preferencia = (TextView) findViewById(R.id.tv_PreferenciaCompartida);
        tv_preferencia.setText(preferencia);
    }
}