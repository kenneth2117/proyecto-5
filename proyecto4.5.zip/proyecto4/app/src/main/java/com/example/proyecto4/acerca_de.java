package com.example.proyecto4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class acerca_de extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acerca_de);
    }
}