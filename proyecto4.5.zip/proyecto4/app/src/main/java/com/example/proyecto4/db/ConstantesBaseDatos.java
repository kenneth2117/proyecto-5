package com.example.proyecto4.db;

public final class ConstantesBaseDatos {
    public static final String DataBase_Name = "DBMascotas";
    public static final int DataBase_Version=1;

    public static final String TABLE_Mascotas ="Mascota";
    public static final String TABLE_Mascotas_ID ="id";
    public static final String TABLE_Mascotas_NOMBRE ="nombre";
    public static final String TABLE_Mascotas_LIKES ="likes";
    public static final String TABLE_Mascotas_FOTO ="foto";


    public static final String TABLE_LIKES_MASCOTAS ="Likes_Mascota";
    public static final String TABLE_LIKES_MASCOTAS_ID = "id";
    public static final String TABLE_LIKES_MASCOTAS_NUMERO_LIKES = "numero_likes";
    public static final String TABLE_LIKES_MASCOTAS_ID_MASCOTA = "id_mascota";
}
