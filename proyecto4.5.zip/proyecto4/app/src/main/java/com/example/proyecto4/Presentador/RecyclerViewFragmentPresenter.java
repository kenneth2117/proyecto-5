package com.example.proyecto4.Presentador;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;

import com.example.proyecto4.VistaFragment.iRecyclerViewFragments;
import com.example.proyecto4.db.ConstructorMascotas;
import com.example.proyecto4.mascota;

import java.util.ArrayList;

public class RecyclerViewFragmentPresenter implements iRecyclerViewFragmentPresenter {
private iRecyclerViewFragments iRecyclerViewFragment;
private Context context;
private ArrayList<mascota> listaMascota;

    public RecyclerViewFragmentPresenter(iRecyclerViewFragments iRecyclerViewFragment, Context context) {
   this.context = context;
   this.iRecyclerViewFragment = iRecyclerViewFragment;
   obtenerMascotasBaseDatos();
    }

    @Override
    public void obtenerMascotasBaseDatos() {
        ConstructorMascotas constructorMascotas = new ConstructorMascotas(context);
        listaMascota = constructorMascotas.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        iRecyclerViewFragment.inicializarAdaptadorRV(iRecyclerViewFragment.crearAdaptador(listaMascota));
        iRecyclerViewFragment.generarLinearLayoutGrid();
    }
}
