package com.example.proyecto4.Presentador;

public interface iRecyclerViewFragmentPresenter {
    public void obtenerMascotasBaseDatos();
    public void mostrarMascotasRV();
}
