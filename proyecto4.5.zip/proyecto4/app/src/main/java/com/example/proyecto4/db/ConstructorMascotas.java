package com.example.proyecto4.db;

import android.content.ContentValues;
import android.content.Context;

import com.example.proyecto4.R;
import com.example.proyecto4.mascota;

import java.util.ArrayList;

public class ConstructorMascotas {
    private Context context;

    public ConstructorMascotas(Context context) {
        this.context = context;
    }

    public ArrayList<mascota> obtenerDatos(){
       /*  ArrayList<mascota> listaMascota = new ArrayList<>();
       listaMascota.add(new mascota("Scooby", R.mipmap.ic_perro,0));
       listaMascota.add(new mascota("Docky",R.mipmap.ic_coala,5));
        listaMascota.add(new mascota("sally",R.mipmap.ic_coco,4));
        listaMascota.add(new mascota("katy",R.mipmap.ic_gato,2));
        listaMascota.add(new mascota("coli",R.mipmap.ic_perro2,0));*/
       BaseDatos db = new BaseDatos(context);
       insertarTresMascotas(db);
        return db.Obtener_Todos_Mascotas();
    }

    public void insertarTresMascotas(BaseDatos db){
        ContentValues contentValues;
        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_NOMBRE,"Scooby");
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_FOTO, R.mipmap.ic_perro);

        db.insertar_Mascota(contentValues);

//segunda mascota
        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_NOMBRE,"Docky");
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_FOTO, R.mipmap.ic_coala);
        db.insertar_Mascota(contentValues);

//tercera mascota
        contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_NOMBRE,"coco");
        contentValues.put(ConstantesBaseDatos.TABLE_Mascotas_FOTO, R.mipmap.ic_coco);

        db.insertar_Mascota(contentValues);
    }
}
